from PIL import Image
from PIL.ExifTags import TAGS
import glob
from Images import *
from Filter import *
import sys
from Archive import *
from SimpleTestGUI import *
from SimpleGUI import *


"""Tasks: 1.read all image files  
          2.create individual image class
   Return: an array of Images
"""
def initailization():
    """read all jpg files"""
    files = glob.glob("*.jpg")
    images = []
    
    """create individual image classes"""
    for i in range(0,len(files)):
        images.append(Images(files[i]))
    return images

def main():   
    allImages = initailization()
    """simpleTestGUI(allImages)"""
    """simpleGUI(allImages)"""
    root = Tk()
    root.geometry("500x500")
    app = App(root,allImages)
    root.mainloop() 
    


if __name__ == '__main__':
    main()