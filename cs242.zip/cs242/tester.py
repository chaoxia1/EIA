from PIL import Image
from PIL.ExifTags import TAGS
import glob
from Images import *
import os

"""Tasks: Read all Exif of one image
   Return: A dictionary of Exif
"""
def get_exif(fn):
    ret = {}
    i = Image.open(fn)
    info = i._getexif()
    """store the information in a dictionary"""
    for tag, value in info.items():
        decoded = TAGS.get(tag, tag)
        ret[decoded] = value
    return ret

def create_dir():
    mypath = 'new folder'
    if not os.path.isdir(mypath):
      os.makedirs(mypath)

print get_exif("a.jpg")
"""create_dir()"""