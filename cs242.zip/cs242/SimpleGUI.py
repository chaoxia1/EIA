from PIL import Image
from PIL.ExifTags import TAGS
import glob
from Images import *
from Filter import *
import os,sys
from Archive import *
from Tkinter import *


class App:
    def __init__(self, master,images):
        
        self.ims = images
        self.printAll(images)
        
        frame = Frame(master)
        frame.grid()
        master.title("Photot Archiving Wizard")
        
        self.filter = StringVar(master)
        self.filter.set("FocalLength")
        self.filtOption = OptionMenu(master, self.filter, "FocalLength", "DateTime", "FNumber", "ApertureValue","Model","Software")
        self.filtOption.grid(row=1,column=0,sticky=W)
        
        self.filtButton = Button(frame, text="Filter", command=self.goFilter)
        self.filtButton.grid(row=2, column=0,sticky=W)
        
        self.archive = StringVar(master)
        self.archive.set("FocalLength")
        self.archOption = OptionMenu(master, self.archive, "FocalLength", "DateTime", "FNumber", "ApertureValue","Model","Software")
        self.archOption.grid(row=1,column=1,sticky=W)
        
        self.archButton = Button(frame, text="Archive", command=self.goArchive)
        self.archButton.grid(row=2, column=1,sticky=W)
        

        self.ScenButton = Button(frame, text="Scene Archive", command=self.goSceneArchive)
        self.ScenButton.grid(row=0, column=0,sticky=W)
        
        self.ReleButton = Button(frame, text="Release", command=self.goRelease)
        self.ReleButton.grid(row=4, column=0,sticky=W)
    
        self.quitButton = Button(frame, text="QUIT", fg="red", command=frame.quit)
        self.quitButton.grid(row=4, column=1,sticky=W)

    
    def printAll(self,ims):
        print "Images detected"
        for i in range(0,len(ims)):
            print ims[i].name
            if(ims[i].dir != ''):
                print '(',ims[i].dir,')'
    
    def goArchive(self):
        newArchive = Archive(self.ims,self.archive.get())
        newArchive.autoArchive()
        print self.archive.get()
    
    def goFilter(self):
        newView = Filter(self.ims,self.filter.get())
        newView.view()
        print self.filter.get()
    
    def goRelease(self):
        newArchive = Archive(self.ims,'')
        newArchive.deArchive()
        print "release"
    
    def goSceneArchive(self):
        newArchive = Archive(self.ims,'')
        newArchive.sceneArchive()
        print "Scene Archine"
